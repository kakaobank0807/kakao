package com.bank.trade;

public class TradeDTO {
	private int tno, topno, tipno, tmoney;
	private String ttime, taccount, tip;
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public int getTopno() {
		return topno;
	}
	public void setTopno(int topno) {
		this.topno = topno;
	}
	public int getTipno() {
		return tipno;
	}
	public void setTipno(int tipno) {
		this.tipno = tipno;
	}
	public int getTmoney() {
		return tmoney;
	}
	public void setTmoney(int tmoney) {
		this.tmoney = tmoney;
	}
	public String getTtime() {
		return ttime;
	}
	public void setTtime(String ttime) {
		this.ttime = ttime;
	}
	public String getTaccount() {
		return taccount;
	}
	public void setTaccount(String taccount) {
		this.taccount = taccount;
	}
	public String getTip() {
		return tip;
	}
	public void setTip(String tip) {
		this.tip = tip;
	}	
}
